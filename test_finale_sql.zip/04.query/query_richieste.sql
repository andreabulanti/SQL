use toysgroup;
-- Verificare che i campi definiti come PK siano univoci
-- Eseguo una query di select sulle PK di ciascuna tabella con la clausola HAVING > 1.
-- Se il risultato è = null, la PK è univoca.

SELECT 
    product_category.category_id
FROM
    product_category
GROUP BY product_category.category_id
HAVING COUNT(*) > 1;

SELECT 
    product.product_id
FROM
    product
GROUP BY product.product_id
HAVING COUNT(*) > 1;

SELECT 
    sales.sales_id
FROM
    sales
GROUP BY sales.sales_id
HAVING COUNT(*) > 1;

SELECT 
    region.region_id
FROM
    region
GROUP BY region.region_id
HAVING COUNT(*) > 1;

SELECT 
    state.state_id
FROM
    state
GROUP BY state.state_id
HAVING COUNT(*) > 1;

-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno

select year(sales_date) as sales_year, product.product_name, round(SUM(sales.sales_quantity * sales.sales_unitprice),2) as total_revenue 
from product, sales
where product.product_id = sales.product_id
group by product.product_name, sales_year
order by 1;

-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

select year(sales_date) as sales_year, state.state_name, round(SUM(sales.sales_quantity * sales.sales_unitprice),2) as total_revenue 
from state, sales
where state.state_id = sales.state_id
group by sales_year, state.state_name
order by 1 asc, 3 desc;

-- Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
-- la risposta è toys_second_category con 162 vendite totali

SELECT product_category.category_name, COUNT(*) as total_category_request
FROM product_category
INNER JOIN product AS product
ON product_category.category_id = product.category_id
INNER JOIN sales AS sales
ON product.product_id = sales.product_id
GROUP BY
product_category.category_name
order by 2 desc
limit 1;

-- Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
-- prima opzione subquey, seconda opzione left outer join
-- in ogni caso nel mio database non esistono prodotti non venduti

select product.product_name from product
WHERE not exists (
					select sales.product_id from sales
                    where sales.product_id = product.product_id
                    );


select product.product_name
from product
left outer join sales as sales
on product.product_id = sales.product_id
where sales.product_id is null;

-- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente)
with max_date_sales as (
select sales.product_id, max(sales.sales_date) as max_sales
from sales
group by sales.product_id
)
select product.product_name, max_date_sales.max_sales
from product as product
inner join max_date_sales
on product.product_id = max_date_sales.product_id;

-- BONUS: Esporre l’elenco delle transazioni indicando nel result set il codice documento, 
-- la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della 
-- regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)

SELECT 
    sales.sales_id,
    sales.sales_date,
    product.product_name,
    product_category.category_name,
    state.state_name,
    region.region_name,
    CASE
        WHEN DATEDIFF(CURRENT_DATE(), sales.sales_date) > 180 THEN "True"
        ELSE "False"
    END AS boolean_condition
FROM
    product_category AS product_category,
    sales AS sales,
    product AS product,
    state AS state,
    region AS region
WHERE
    product_category.category_id = product.category_id
        AND product.product_id = sales.product_id
        AND sales.state_id = state.state_id
        AND state.region_id = region.region_id
ORDER BY 1



