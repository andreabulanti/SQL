DROP SCHEMA IF EXISTS ToysGroup;
CREATE SCHEMA ToysGroup;
USE ToysGroup;

-- creazione tabella product_category
CREATE TABLE product_category (
	category_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR (50)
    );

-- creazione tabella product_category
CREATE TABLE product (
	product_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    category_id INT NOT NULL,
    product_name VARCHAR (50),
    FOREIGN KEY (category_id) REFERENCES product_category(category_id)
    ON DELETE RESTRICT
    );

-- creazione tabella region
CREATE TABLE region (
	region_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    region_name VARCHAR (50)
    );

-- creazione tabella state
CREATE TABLE state (
	state_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    region_id INT NOT NULL,
    state_name VARCHAR (50),
    FOREIGN KEY (region_id) REFERENCES region(region_id)
	ON DELETE RESTRICT
    );
    
-- creazione tabella sales
CREATE TABLE sales (
	sales_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    state_id INT NOT NULL,
    sales_quantity INT,
    sales_unitprice FLOAT,
    sales_date DATE,
    FOREIGN KEY (product_id) REFERENCES product(product_id)
	ON DELETE RESTRICT,
    FOREIGN KEY (state_id) REFERENCES state(state_id)
    ON DELETE RESTRICT
    )
    